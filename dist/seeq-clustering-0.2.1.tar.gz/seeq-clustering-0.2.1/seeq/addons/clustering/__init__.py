from .app.clusterApp import GUI
from .app.clusterApp.checksum import checksum as __script_name__
from ._version import __version__