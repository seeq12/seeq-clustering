import sys

__all__ = ('loading', )


def loading():
	sys.stdout.write("\rLoading....")
	sys.stdout.flush()
	return