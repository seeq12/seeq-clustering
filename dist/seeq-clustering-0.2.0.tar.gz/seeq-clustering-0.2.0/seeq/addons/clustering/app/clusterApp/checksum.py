checksum = 'Clustering.py:NUMERIC:q2tYWyXR+cw8'
